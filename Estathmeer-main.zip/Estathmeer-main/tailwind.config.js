/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    extend: {
      textColor: {
        light: "#fffff0", // Ivory
      },
    },
  },
  plugins: [],
};

